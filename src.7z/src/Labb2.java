import java.util.ArrayList;

public class Labb2 {
    /*todo
    gör så files sparar till ett bättre ställe
    gör så files backar upp filer istället för att spara över
    * */
    public static void main(String[] args) {
        RunCategory runCategory = new RunCategory();
        runCategory.running();
    }
}
